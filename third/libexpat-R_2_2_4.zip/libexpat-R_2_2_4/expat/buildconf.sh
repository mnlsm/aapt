#! /bin/sh
exec autoreconf -i -f
